# calibrar 0.3
* new optimization methods available: ...
* control of numerical gradient computations
* parallel numerical gradient computations 
* 'calibrate' function is a generic now.
* replicates argument for stochastic functions 
* added to demos for optimization of stochastic models.
* several minor bugs fixed
* getCalibrationInfo, createObjectiveFuction and getObserved data are replaced
and deprecated.
* spline_par function to simplify the estimation of smooth time-varying parameters.

# calibrar 0.2
* par argument for the calibrate function can be a list
* optimization methods from optimx, stats::optim and cmaes can be used
* several minor bugs fixed

# calibrar 0.1
* First release
