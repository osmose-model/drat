  require("setRNG")
  Sys.info()
 
  random.number.test() 
