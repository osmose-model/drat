### R code from vignette source 'setRNG.Stex'

###################################################
### code chunk number 1: setRNG.Stex:6-7
###################################################
 options(continue="  ")


###################################################
### code chunk number 2: setRNG.Stex:14-15
###################################################
library("setRNG") 


###################################################
### code chunk number 3: setRNG.Stex:34-35 (eval = FALSE)
###################################################
##  rng <- NULL


###################################################
### code chunk number 4: setRNG.Stex:38-42 (eval = FALSE)
###################################################
## if(!require("setRNG")) {
##     stop("This function requires the setRNG package.") }
## if(is.null(rng)) rng <- setRNG() else 
##             {old.rng <- setRNG(rng);  on.exit(setRNG(old.rng))  }


