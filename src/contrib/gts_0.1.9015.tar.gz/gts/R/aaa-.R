#' @importFrom ncdf4 nc_open nc_close ncvar_get ncatt_get
NULL
#' @importFrom nctools ncvar_dim write_ncdf
NULL
#' @export write_ncdf
NULL
#' @importFrom reshape2 melt
NULL
#' @export melt
NULL
#' @importFrom fields poly.image image.plot interp.surface.grid tim.colors
#' imageplot.info imageplot.setup
NULL
#' @importFrom maptools map2SpatialPolygons
NULL
#' @importFrom lubridate yday<- year month ymd leap_year parse_date_time period
#' ymd_hms days_in_month parse_date_time days_in_month seconds
NULL
#' @importFrom mgcv gam
NULL
#' @importFrom akima interp interpp bilinear bicubic
NULL
#' @importFrom sp SpatialPoints over CRS proj4string
NULL
#' @importFrom sf st_sfc st_transform st_point
NULL
#' @importFrom colorful divergencePalette
NULL
#' @importFrom stats gaussian integrate quantile sd
NULL
#' @importFrom maps map
NULL
