library(kali)
library(gts)
library(lubridate)

file = "S:/BGC/nemo-eco3m-s/gol/nemo-eco3m-s_gol_mesozoo_19980101_20130615.nc"

x = read_gts(file)
plot(x, slice = 5)

# WINDOW

x1 = window(x, start=c(2000, 1))
plot(x1)
x1 = window(x1, start=ymd("2000-01-01"))
# if date, use time vector
# if vector, calculate date and apply previous method
# recalculate attribute tsp

start = ymd("2001-01-01")
end = ymd("2015-01-01")

# add value to info$time$value
# mask: similar to area, return mask or create mask. Create assign method.

# interpolate accept z as array
#method for class z=array

# create assign method to area

