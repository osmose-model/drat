#' @importFrom foreach foreach %dopar%
NULL
#' @importFrom stats optim pnorm rexp rnorm rpois runif weighted.mean
NULL
#' @importFrom utils as.relistable read.csv relist write.csv
NULL
