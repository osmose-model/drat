optsp <- new.env()
optsp$deps <- 1e-6 # changed from 1e-8 20220223
