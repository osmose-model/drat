/* 
 * 
 * OSMOSE (Object-oriented Simulator of Marine Ecosystems)
 * http://www.osmose-model.org
 * 
 * Copyright (C) IRD (Institut de Recherche pour le Développement) 2009-2020
 * 
 * Osmose is a computer program whose purpose is to simulate fish
 * populations and their interactions with their biotic and abiotic environment.
 * OSMOSE is a spatial, multispecies and individual-based model which assumes
 * size-based opportunistic predation based on spatio-temporal co-occurrence
 * and size adequacy between a predator and its prey. It represents fish
 * individuals grouped into schools, which are characterized by their size,
 * weight, age, taxonomy and geographical location, and which undergo major
 * processes of fish life cycle (growth, explicit predation, additional and
 * starvation mortalities, reproduction and migration) and fishing mortalities
 * (Shin and Cury 2001, 2004).
 * 
 * Contributor(s):
 * Yunne SHIN (yunne.shin@ird.fr),
 * Morgane TRAVERS (morgane.travers@ifremer.fr)
 * Ricardo OLIVEROS RAMOS (ricardo.oliveros@gmail.com)
 * Philippe VERLEY (philippe.verley@ird.fr)
 * Laure VELEZ (laure.velez@ird.fr)
 * Nicolas BARRIER (nicolas.barrier@ird.fr)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation (version 3 of the License). Full description
 * is provided on the LICENSE file.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 * 
 */

package fr.ird.osmose.process.mortality.additional;

import fr.ird.osmose.School;
import fr.ird.osmose.Species;
import fr.ird.osmose.process.mortality.AbstractMortalitySpecies;
import fr.ird.osmose.util.timeseries.ByRegimeTimeSeries;
import fr.ird.osmose.util.timeseries.SeasonTimeSeries;

/**
 * Constant larval mortality rate over time.
 *
 * @author P. Verley
 */
public class AnnualLarvaMortality extends AbstractMortalitySpecies {

    // Larval mortality rate expressed in [time_step^-1]
    private double[] mortRate;

    public AnnualLarvaMortality(int rank, Species species, String stage0) {
        super(rank, species);
        this.stage0 = stage0;
    }

    @Override
    public void init() {
        
        int nStepYear = getConfiguration().getNStepYear();
        // reading base mortality rate
        String keyShift = String.format("mortality.additional.larva.rate.shift.sp%d", getFileSpeciesIndex());
        String keyVal = String.format("mortality.additional.larva.rate.sp%d", getFileSpeciesIndex());
        //String keyValLog = String.format("mortality.additional.larva.rate.log.sp%d", getFileSpeciesIndex());

        // test if only one of the two values exists
        //if (!getConfiguration().isNull(keyValLog) && !getConfiguration().isNull(keyVal)) {
        //    String message = String.format("Both %s and %s parameters are defined. Choose only one.\n", keyValLog, keyVal);
        //    error(message, new Exception());
        //}

        //boolean useLog;
        ByRegimeTimeSeries mortRateSeries;
        mortRateSeries = new ByRegimeTimeSeries(keyShift, keyVal);
        mortRateSeries.init();
        double[] mortRateBase = mortRateSeries.getValues();
        
        //if(getConfiguration().isNull(keyValLog)) {
        //    // If the key for log values is Null, assume fishing mort in standard mode
        //    mortRateSeries = new ByRegimeTimeSeries(keyShift, keyVal);
        //    useLog = false;
        //} else {
        //    // If the key for log values is not null, assume fishing mort in log
        //    mortRateSeries = new ByRegimeTimeSeries(keyShift, keyValLog);
        //    useLog = true;
        //}
        
        //mortRateSeries.init();
        //double[] mortRateBase = mortRateSeries.getValues();
        
        //if (useLog) {
        //    for (int i = 0; i < mortRateBase.length; i++) {
        //        mortRateBase[i] = Math.exp(mortRateBase[i]);
        //    }
        //}
        
        // reading multiplier
        double multiplier;
        if (getConfiguration().isNull("mortality.additional.larva.rate.multiplier.sp" + getFileSpeciesIndex())) {
            multiplier = 1;
        } else {
            multiplier = getConfiguration()
                    .getDouble("mortality.additional.larva.rate.multiplier.sp" + getFileSpeciesIndex());
        }
        
        // reading season
        SeasonTimeSeries season = new SeasonTimeSeries("mortality.additional.larva.rate.seasonality", "sp" + getFileSpeciesIndex());
        season.init();
        double[] seasonValues = season.getValues();
        
        // computing final mortality rate
        mortRate = new double[getConfiguration().getNStep()];
        for(int i = 0; i < getConfiguration().getNStep(); i++) {
            mortRate[i] = multiplier * mortRateBase[i] * seasonValues[i] / nStepYear;   
        }
    }

    @Override
    public double getRate(School school) {
        return mortRate[getSimulation().getIndexTimeSimu()];
    }
    
    public double[] getRates() {
        return mortRate;   
    }
}
