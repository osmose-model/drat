library(fields)
library(calibrar)

phi = function(T, T1, T2, Topt) {
  numerator = (T - T1) * (T - T2)
  denominator = numerator - (T - Topt)^2
  phi = numerator / denominator
  # phi = ifelse(T>Tmax | T<Tmin, 0, phi)
  return(phi)
}

phim = function(T, c_m, e_m) {
  k = 8.62e-5
  Tk = T + 273.15
  return(c_m*exp(-(e_m/k)*(1/Tk)))
}

phiT = function(T, e_M, e_D, Tp) {
  # Recovers the temperature of the school cell
  k = 8.62e-5
  numerator = exp(-e_M / (k * (T + 273.15)))
  denominator = (1 + (e_M / (e_D - e_M)) * 
                   exp((e_D) / k * (1 / (Tp + 273.15) - 1 / (T + 273.15))))
  normalizer = exp(-e_M / (k * (Tp + 273.15))) /
    (1 + e_M / (e_D - e_M))
  
  output = numerator / denominator / normalizer
  
  return(output)
}

Enet = function(h, T, Imax, e_M, e_D, Tp, c_m, e_m, assimilation=0.8) {
  # T = seq(from=Tmin-2*dT, to=Tmax+dT/2, by=0.01)
  T = sort(T)
  dT = max(diff(T))
  Egross = Imax*assimilation*phiT(T, e_M, e_D, Tp)
  Emaint = phim(T, c_m, e_m)
  Enet = h*Egross - Emaint
  Topt = T[which.max(Enet)]
  Tmin = T[which.min(ifelse(T<=Topt, Enet, Inf)^2)]
  Tmax = T[which.min(ifelse(T<Topt, Inf, Enet)^2)]
  inNiche = any(Enet>= -dT)
  out = list(T=T, Enet=Enet, Egross=Egross, Emaint=Emaint, Tmin=Tmin, Topt=Topt, Tmax=Tmax, inNiche=inNiche)
  class(out) = "EnergyBudget"
  return(out)
}

Enetlite = function(h, T, eta_crit, Imax, Tmin, Topt, Tmax, assimilation=0.8) {
  # T = seq(from=Tmin-2*dT, to=Tmax+dT/2, by=0.01)
  T = sort(T)
  dT = max(diff(T))
  
  r = Tmax - Tmin
  hmin = (eta_crit/(1-eta_crit))*(Tmin-Topt)^2
  hmax = (eta_crit/(1-eta_crit))*(Tmax-Topt)^2
  H = (hmax-hmin)/r
  
  k1 = (-(r+H) + sqrt((r+H)^2 + 4*hmin))/2
  k2 = k1 + H
  T1 = Tmin - k1
  T2 = Tmax + k2
  
  Enet = assimilation*Imax*(h*phi(T, T1, T2, Topt) - eta_crit)
  
  Topt = T[which.max(Enet)]
  Tmin = T[which.min(ifelse(T<=Topt, Enet, Inf)^2)]
  Tmax = T[which.min(ifelse(T<Topt, Inf, Enet)^2)]
  inNiche = any(Enet>= -dT)
  out = list(T=T, Enet=Enet, Egross=NA, Emaint=NA, Tmin=Tmin, Topt=Topt, Tmax=Tmax, inNiche=inNiche)
  class(out) = "EnergyBudget"
  return(out)
}

plot.EnergyBudget = function(x, add=TRUE, full=FALSE, ylim=NULL, las=1, ...) {
  if(!isTRUE(add)) {
    if(isTRUE(full)) {
      ylim = range(x$Enet, x$Egross, x$Emaint, na.rm=TRUE)
    }
    plot(x$T, x$Enet, type="l", ylim=ylim, las=las, xlab="Temperature", ylab="Net Energy", ...)
    abline(h=0, lty=3, col="red")
  } else {
    lines(x$T, x$Enet, ...)
  }
  
  if(isTRUE(full)) {
    lines(x$T, x$Egross, col="blue", ...)
    lines(x$T, x$Emaint, col="red", ...)
    abline(v=c(x$Tmin, x$Topt, x$Tmax), lty=3)
  }
  
  return(invisible())
}


# Atlantic Herring example ------------------------------------------------

# Atlantic Herring
Imax = 14.01618
e_crit = 0.57 # predation.efficiency.critical
# maintainance 
c_m = 1.49e+11
e_m = 0.5956822
# mobilisation
e_M = 1.929569
e_D = 1.92967 # greater than e_M
Tp = 43.09747

beta = 0.75
assimilation = 0.8

Tmin = -1
Topt = 12.56059132
Tmax = 26.21059132

q = phim(Topt, c_m, e_m)/Imax/assimilation # predation.efficiency.critical.sp0?
eta_crit = q

w = 100
T= seq(from=-8, to=28, by=0.005)
T0= seq(from=-5, to=25, by=0.05)
hs = seq(from=0, to=1, by=0.005)
Hs = seq(from=0, to=1, by=0.05)
qs = seq(from=0, to=1, by=0.005)

out = list()
for(ih in seq_along(hs)) {
  out[[ih]] = Enet(h=hs[ih], T, Imax, e_M, e_D, Tp, c_m, e_m)
}

enet = do.call(rbind, sapply(out, FUN="[", i="Enet"))
xTopt = unlist(sapply(out, FUN="[", i="Topt"))
xTmin = unlist(sapply(out, FUN="[", i="Tmin"))
xTmax = unlist(sapply(out, FUN="[", i="Tmax"))
iN = which(unlist(sapply(out, FUN="[", i="inNiche")))

h1.00 = Enet(h=1, T, Imax, e_M, e_D, Tp, c_m, e_m)
h0.80 = Enet(h=0.80, T, Imax, e_M, e_D, Tp, c_m, e_m)
h0.57 = Enet(h=0.57, T, Imax, e_M, e_D, Tp, c_m, e_m)
h0.38 = Enet(h=0.38, T, Imax, e_M, e_D, Tp, c_m, e_m)


# Figure 1 ----------------------------------------------------------------

plot(h1.00, add=FALSE, full=TRUE, lwd=3)
text(x=-2, y=c(15, 14, 13)+0.5, 
     labels=c("NET ENERGY", "GROSS ENERGY", "MAINTENANCE ENERGY"),
      col=c("black", "blue", "red"), adj=0, font=2)


# Figure 2 ----------------------------------------------------------------

plot(h1.00, add=FALSE, lwd=2)
text(26, 5, expression(xi == 1.0), col="black", font=2)
plot(h0.80, col="blue", lwd=2)
text(26, 4, expression(xi == 0.8), col="blue", font=2)
plot(h0.57, col="green", lwd=2)
text(26, 3, expression(xi == 0.57), col="green", font=2)
plot(h0.38, col="orange", lwd=2)
text(26, 2, expression(xi == 0.38), col="orange", font=2)


# Figure 3 ----------------------------------------------------------------

H1.00 = Enetlite(h=1, T, eta_crit, Imax, min(xTmin[iN]), max(xTopt[iN]), max(xTmax[iN]), assimilation=0.8)
plot(H1.00, add=FALSE, lwd=2, ylim=c(-2, 7.5), las=1)
abline(h=max(H1.00$Enet), lty=3, col="red")
text(5, 0.35 + max(H1.00$Enet), expression(alpha*I[max](1-xi[crit])),font=2)


# Figure 4 ----------------------------------------------------------------

plot(H1.00, add=FALSE, lwd=2, ylim=c(-2, 6.5), las=1)
plot(h1.00, lwd=2, col="blue")
text(x=25, y=c(6,5.5), labels=c("FULL", "LITE"), col=c("black", "blue"), adj=0, font=2)


out1 = list()
for(ih in seq_along(Hs)) {
  out1[[ih]] = Enet(h=Hs[ih], T0, Imax, e_M, e_D, Tp, c_m, e_m)
}
enet1 = do.call(rbind, sapply(out1, FUN="[", i="Enet"))

plot(H1.00, add=FALSE)
plot(h1.00)

xh1.00 = Enet(h=1, T0, Imax, e_M, e_D, Tp, c_m, e_m)

.fit = function(par) {
  eta_crit = par[1]
  Tmin = par[2]
  Topt = par[3]
  Tmax = par[4]
  sim = Enetlite(h=1, T0, eta_crit=eta_crit, Imax, Tmin=Tmin, Topt=Topt, Tmax=Tmax)
  out = sum((sim$Enet-xh1.00$Enet)^2)
  return(out)
}

par0 = c(0.3, min(xTmin[iN]), max(xTopt[iN]), max(xTmax[iN]))
opt = optim2(par0, fn=.fit, lower=c(0, -10, 0, 0), upper=c(1,5,20,30), method="AHR-ES")

heta_crit = opt$par[1]
hTmin = opt$par[2]
hTopt = opt$par[3]
hTmax = opt$par[4]

.fit2 = function(par) {
  eta_crit = par[1]
  Tmin = par[2]
  Topt = par[3]
  Tmax = par[4]
  xout = list()
  for(ih in seq_along(Hs)) {
    xout[[ih]] = Enetlite(h=Hs[ih], T0, eta_crit=eta_crit, Imax, Tmin, Topt, Tmax)
  }
  sim = do.call(rbind, sapply(xout, FUN="[", i="Enet"))
  out = sum((sim - enet1)^2)
  return(out)
}

opt2 = optim2(par0, fn=.fit2, lower=c(0, -10, 0, 0), upper=c(1,5,20,30), method="AHR-ES")

geta_crit = opt2$par[1]
gTmin = opt2$par[2]
gTopt = opt2$par[3]
gTmax = opt2$par[4]

# new phase plot

out2 = list()
for(ih in seq_along(hs)) {
  out2[[ih]] = Enetlite(h=hs[ih], T, eta_crit=geta_crit, 
                        Imax, Tmin=gTmin, Topt=gTopt, Tmax=gTmax)
}

enet2 = do.call(rbind, sapply(out2, FUN="[", i="Enet"))
xTopt2 = unlist(sapply(out2, FUN="[", i="Topt"))
xTmin2 = unlist(sapply(out2, FUN="[", i="Tmin"))
xTmax2 = unlist(sapply(out2, FUN="[", i="Tmax"))
iN2 = which(unlist(sapply(out2, FUN="[", i="inNiche")))


# plot

zlim = range(c(enet, enet2))/Imax
zlim = range(pretty(zlim))*1.05
n = 512
col = colorful::divergencePalette(n=n, zlim=zlim, 
                                  col=c("firebrick3", "dodgerblue3"), symmetric = FALSE)

par(mar=c(4,4,1,1), oma=c(1,1,1,1))
layout(mat=matrix(c(1,3,2,3), nrow=2), heights=c(5,1))

image(hs, T, enet/Imax, col=col, las=1, zlim=zlim, 
           xlab="Predation Efficiency", ylab="Temperature")
lines(hs[iN], xTopt[iN], lty=3)
lines(c(rev(hs[iN]), hs[iN]), c(rev(xTmin[iN]),xTmax[iN]), col="grey80")

image(hs, T, enet2/Imax, col=col, las=1, zlim=zlim, 
           xlab="Predation Efficiency", ylab="Temperature")
lines(hs[iN2], xTopt2[iN2], lty=3)
lines(c(rev(hs[iN2]), hs[iN2]), c(rev(xTmin2[iN2]),xTmax2[iN2]), col="grey80")

par(mar=c(2,10,3,10))
zcol = matrix(seq(from=zlim[1], to=zlim[2], length.out=n), ncol=1)
image(as.numeric(zcol), 1, zcol, zlim=zlim, col=col, axes=FALSE, 
      ylab="", xlab="")
mtext("Relative Net Energy", 3, cex=0.8)
axis(1); box()

par(mfrow=c(1,1))
par(mar=c(4,4,2,1), oma=c(1,1,1,1))
image.plot(hs, T, enet/Imax, col=col, las=1, zlim=zlim, 
      xlab="Predation Efficiency", ylab="Temperature", main="Relative Net Energy")
lines(hs[iN], xTopt[iN], lty=3)
lines(c(rev(hs[iN]), hs[iN]), c(rev(xTmin[iN]),xTmax[iN]), col="grey80")



# TPC plot ----------------------------------------------------------------

x = h1.00
par(mar=c(2,3,1,1))
plot(tail(x$T, -500), tail(x$Enet, -500), axes=FALSE, xlab="", ylab="", type="l",
     ylim=c(-0.5, 1.1*max(x$Enet)), xlim=c(-8, 30), col=4, lwd=3)
arrows(x0=par("usr")[1]+2, y0=-0.5, y1=par("usr")[4], lty=1, lwd=3)
segments(x0=x$Topt, y0=0, y1=max(x$Enet), lty=3)
axis(2, at=0, tick = FALSE, las=1, line=-0.5, font=2)
ptr = c(0.7*x$Tmin+0.3*x$Topt, 0.5*x$Tmax+0.5*x$Topt)
text(x=mean(ptr), y=0.7, labels = "PTR", font=2, cex=1.5)
polygon(x=c(ptr, rev(ptr)), y=c(0,0,0.3,0.3), angle=45, col=3)
polygon(x=c(ptr, rev(ptr)), y=c(0,0,0.3,0.3), angle=45, col=1, density=10, lwd=2)
arrows(x0=par("usr")[1], x1=par("usr")[2], y0=0, lty=1, lwd=3)
abline(h=0, lty=1, lwd=3)
ref = c(x$Tmin, x$Topt, 0.7*x$Tmax+0.3*x$Topt, x$Tmax)
axis(1, at=ref, labels=c("Tmin", "Topt", "Tpk", "Tmax"), pos=0, font=2, lwd.ticks=3)
axis(1, at=ref[4], labels="Tmax", pos=0, font=2)
mtext("TRAIT PERFORMANCE", side=2, line=-1, font=2)
mtext("TEMPERATURE", side=1, font=2)








plot(qs, log10(out2))
q = qs[which.min(out2)]

H1.00 = Enetlite(h=1.00, T, q=xq, Imax, xTmin, xTopt, xTmax)
H0.80 = Enetlite(h=0.80, T, q=xq, Imax, xTmin, xTopt, xTmax)
H0.57 = Enetlite(h=0.57, T, q=xq, Imax, xTmin, xTopt, xTmax)
H0.38 = Enetlite(h=0.38, T, q=xq, Imax, xTmin, xTopt, xTmax)

m1.00 = Enetlite(h=1.00, T, q=xq, Imax, xTmin-3, max(Topt), xTmax+3)
x1.00 = m1.00
x1.00$Enet = ifelse(x1.00$T < x1.00$Tmin, -(abs(x1.00$Enet)+1)^0.75+1, x1.00$Enet)

plot(x1.00, add=FALSE, lwd=2)

plot(h1.00, col="red")
plot(m1.00)

plot(H1.00, add=FALSE, lwd=2)
plot(H0.80, col="blue", lwd=2)
plot(H0.57, col="green", lwd=2)
plot(H0.38, col="orange", lwd=2)

plot(h1.00)
plot(h0.80, col="blue")
plot(h0.57, col="green")
plot(h0.38, col="orange")


# Tmin, Topt and Tmax as function of predation efficiency (I/Imax). Classical OSMOSE assumes critical predation efficiency as 0.57, where ingestion only covers maintenance. 

tpc = phi(T, Tmin, Tmax, Topt)
plot(T, tpc, type="l")

