/*
 *
 * OSMOSE (Object-oriented Simulator of Marine Ecosystems)
 * http://www.osmose-model.org
 *
 * Copyright (C) IRD (Institut de Recherche pour le Développement) 2009-2020
 *
 * Osmose is a computer program whose purpose is to simulate fish
 * populations and their interactions with their biotic and abiotic environment.
 * OSMOSE is a spatial, multispecies and individual-based model which assumes
 * size-based opportunistic predation based on spatio-temporal co-occurrence
 * and size adequacy between a predator and its prey. It represents fish
 * individuals grouped into schools, which are characterized by their size,
 * weight, age, taxonomy and geographical location, and which undergo major
 * processes of fish life cycle (growth, explicit predation, additional and
 * starvation mortalities, reproduction and migration) and fishing mortalities
 * (Shin and Cury 2001, 2004).
 *
 * Contributor(s):
 * Yunne SHIN (yunne.shin@ird.fr),
 * Morgane TRAVERS (morgane.travers@ifremer.fr)
 * Ricardo OLIVEROS RAMOS (ricardo.oliveros@gmail.com)
 * Philippe VERLEY (philippe.verley@ird.fr)
 * Laure VELEZ (laure.velez@ird.fr)
 * Nicolas BARRIER (nicolas.barrier@ird.fr)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation (version 3 of the License). Full description
 * is provided on the LICENSE file.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
package fr.ird.osmose.process;

import java.util.ArrayList;
import java.util.List;

import fr.ird.osmose.School;
import fr.ird.osmose.Species;
import fr.ird.osmose.process.bioen.WeightedRandomDraft;
import fr.ird.osmose.util.timeseries.SingleTimeSeries;

/**
 * This class controls the reproduction process in the simulated domain. The
 * user defines the spawning season (a CSV file per Species) either annual or
 * interannual, the percentage of female in the population (sex ratio) and the
 * annual number of eggs per gramme of mature female (beta) for every species.
 * Osmose estimates the spawning stock biomass (SSB) and calculates the number
 * of eggs to be released in the system at every time steps.<br />
 * During the spin-up of the simulation (duration of spin-up either set by the
 * user or set by default to the lifespan of the longest-lived species) Osmose
 * prevents species collapse by artificially setting the SSB to a predefined
 * level (user defined, this parameter could/should be calibrated) in order to
 * guarantee egg release.
 */
public class ReproductionProcess extends AbstractProcess {

    /**
     * Distribution of the spawning throughout the year
     */
    private double[][] seasonSpawning;
    private double[][] seasonSpawningBioen;
    /*
     * Percentage of female in the population
     */
    private double[] sexRatio;
    /*
     * Annual number of eggs per gram of mature female
     */
    private double[] beta;
    /*
     * All the modes of reproduction
     */
    private String[] modes;
    /*
     * Seeding biomass in tonne
     */
    private double[] seedingBiomass;

    private double[] seedingAbundance;

    private boolean[] reproduce;

    /*
     * Year max for seeding collapsed species, in number of time steps
     */
    private int yearMaxSeeding;

    private int dateGenoTransmission;

    private WeightedRandomDraft<School> weight_rand;

    @FunctionalInterface
    private interface RunInterface {
        public void run();
    }

    RunInterface runInterface;

    @FunctionalInterface
    private interface SpawnerInterface {
        public double getSpawner(School school);
    }

    SpawnerInterface spawnerInterface[];

    @FunctionalInterface
    private interface SeedingInterface {
        public double getSeeding(int species_index);
    }

    SeedingInterface seedingInterface[];


    public ReproductionProcess(int rank) {
        super(rank);
        weight_rand = new WeightedRandomDraft<>(rank);
    }

    @Override
    public void init() {

        boolean normalisationEnabled = false;
        String mode;

        if (!getConfiguration().isNull("reproduction.normalisation.enabled")) {
            normalisationEnabled = getConfiguration().getBoolean("reproduction.normalisation.enabled");
        }

        // check for whether the genetic module is enabled.
        if (getConfiguration().isGeneticEnabled()) {
            runInterface = () -> run_genet();
        } else {
            runInterface = () -> run_nogenet();
        }

        int nSpecies = getNSpecies();
        sexRatio = new double[nSpecies];
        beta = new double[nSpecies];
        modes = new String[nSpecies];
        spawnerInterface = new SpawnerInterface[nSpecies];
        seedingInterface = new SeedingInterface[nSpecies];
        reproduce = new boolean[nSpecies];
        seasonSpawning = new double[nSpecies][];
        int cpt = 0;
        for (int i : getConfiguration().getFocalIndex()) {
            if (!getConfiguration().isNull("reproduction.season.file.sp" + i)) {
                SingleTimeSeries ts = new SingleTimeSeries();
                ts.read(getConfiguration().getFile("reproduction.season.file.sp" + i));
                seasonSpawning[cpt] = ts.getValues();
            } else {
                // Even spawning season throughout the year
                seasonSpawning[cpt] = new double[] { 1.d / getConfiguration().getNStepYear() };
            }
            cpt++;
        } // end of reading seasonSpawning

        // recompute seasonality for bioen egg release from gonads
        if (getConfiguration().isBioenEnabled()) {
          bioenSeason();
        }
        
        
        cpt = 0;
        for (int i : getConfiguration().getFocalIndex()) {
            float sum = 0;
            for (double d : seasonSpawning[cpt]) {
                sum += d;
            }
            if (sum > 0) {
                if (!getConfiguration().isNull("species.reproduction.mode.sp" + i)) {
                    mode = getConfiguration().getString("species.reproduction.mode.sp" + i);
                } else {
                    mode = "oviparity"; // default
                }
                
                if (!getConfiguration().isNull("species.sexratio.sp" + i)) {
                    sexRatio[cpt] = getConfiguration().getDouble("species.sexratio.sp" + i);
                } else {
                    sexRatio[cpt] = 0.5; // default
                }
                
                modes[cpt] = mode;
                String key = (mode.equals("oviparity")) ? "relativefecundity" : "absolutefecundity";

                beta[cpt] = getConfiguration().getDouble("species." + key + ".sp" + i);

                if(mode.equals("oviparity")) {
                    spawnerInterface[cpt] = (school) -> (1e6 * school.getInstantaneousBiomass());
                    seedingInterface[cpt] = (species_index) -> (1e6 * this.getSeedingBiomass(species_index));
                } else {
                    spawnerInterface[cpt] = (school) -> (school.getInstantaneousAbundance());
                    seedingInterface[cpt] = (species_index) -> (this.getSeedingAbundance(species_index));
                }

            }
            reproduce[cpt] = (sexRatio[cpt] > 0.d && beta[cpt] > 0.d);
            cpt++;
        }



        if (normalisationEnabled) {
            info("Normalisation of season spawning is on for all species");
            // normalisation of seasonSpawning.
            if (getConfiguration().isBioenEnabled()) {
                this.normSeasonBioen();
            } else {
                this.normSeason();
            }
        }

        // Seeding biomass
        seedingBiomass = new double[nSpecies];
        cpt = 0;
        for (int fileIndex : getConfiguration().getFocalIndex()) {
            if (!getConfiguration().isNull("population.seeding.biomass.sp" + fileIndex)) {
                seedingBiomass[cpt] = getConfiguration().getDouble("population.seeding.biomass.sp" + fileIndex);
            } else {
                seedingBiomass[cpt] = 0;
            }
            cpt++;
        }

        // Seeding abundance
        seedingAbundance = new double[nSpecies];
        cpt = 0;
        for (int fileIndex : getConfiguration().getFocalIndex()) {
            if (!getConfiguration().isNull("population.seeding.abundance.sp" + fileIndex)) {
                seedingAbundance[cpt] = getConfiguration().getDouble("population.seeding.abundance.sp" + fileIndex);
            } else {
                seedingAbundance[cpt] = 0;
            }
            cpt++;
        }

        // Seeding duration (expressed in number of time steps)
        yearMaxSeeding = 0;
        if (!getConfiguration().isNull("population.seeding.year.max")) {
            yearMaxSeeding = getConfiguration().getInt("population.seeding.year.max")
                    * getConfiguration().getNStepYear();
        } else {
            if(!getConfiguration().getBoolean("population.initialization.relativebiomass.enabled")) {
                for (int i = 0; i < nSpecies; i++) {
                    yearMaxSeeding = Math.max(yearMaxSeeding, getSpecies(i).getLifespanDt());
                }
                warning("Did not find parameter population.seeding.year.max. Osmose set it to "
                        + ((float) yearMaxSeeding / getConfiguration().getNStepYear())
                        + " years, the lifespan of the longest-lived species.");        
            }
        }

        if (this.getConfiguration().isGeneticEnabled()) {
            dateGenoTransmission = (int) getConfiguration().getDouble("population.genotype.transmission.year.start")
                    * getConfiguration().getNStepYear();
            if (dateGenoTransmission < this.getYearSeading()) {
                error("The 'population.genotype.transmission.year.start' parameter must be greater/equal than the 'population.seeding.year.max' one",
                        new Exception());
            }
        }

    }

    @Override
    public void run() {
        runInterface.run();
    }

    /** Legacy reproduction run method in case the genetic module is not enabled */
    public void run_nogenet() {

        if (getConfiguration().isBioenEnabled()) {
            error("ReproductionProcess run method not usable with the bioenergetic module", new Exception());
        }

        // Loop over all species
        for (int cpt = 0; cpt < this.getNSpecies(); cpt++) {

            // ignore species that do not reproduce in this time step
            if (!reproduce[cpt]) {
                continue;
            }

            int nSchool = getConfiguration().getNSchool(cpt);

            Species species = getSpecies(cpt);
            List<School> schoolset = getSchoolSet().getSchools(species);

            // compute number of eggs to be released
            double season = getSeason(getSimulation().getIndexTimeSimu(), species);

            // total number of eggs for the species
            double total_species_eggs = 0.d;

            // if the seeding biomass is not null, loop over sexually mature schools
            for (School school : schoolset) {

                if (school.getSpecies().isSexuallyMature(school)) {
                    // get the school spawners, either in grams (for ovoviviparity)
                    // or as number of individuals
                    double school_spawners = spawnerInterface[cpt].getSpawner(school);
                    // convert spawners into number of eggs
                    double school_nEgg = sexRatio[cpt] * beta[cpt] * season * school_spawners;
                    // increment the total number of eggs
                    total_species_eggs += school_nEgg;
                    // if a positive number of eggs, indicate the school has spawned
                    if (school_nEgg > 0) school.setHasSpawned(true);
                }
            } // end of loop over the school that belong to species i

            if((total_species_eggs == 0) && (getSimulation().getIndexTimeSimu() < yearMaxSeeding)) {
                // if the total number of eggs is 0, i.e no mature individuals
                // we artificially create individuals based on the seeding biomass
                // in this case, weight_rand is never used.
                total_species_eggs = sexRatio[cpt] * beta[cpt] * season * seedingInterface[cpt].getSeeding(cpt);
            }

            if (total_species_eggs == 0.d) {
                // do nothing, zero school
            } else if (total_species_eggs < nSchool) {
                School school0 = new School(species, total_species_eggs);
                getSchoolSet().addReproductionSchool(school0);
            } else if (total_species_eggs >= nSchool) {
                for (int s = 0; s < nSchool; s++) {
                    School school0 = new School(species, total_species_eggs / nSchool);
                    getSchoolSet().addReproductionSchool(school0);
                }
            }
        } // end of species loop

        // Finally, we increment the age and set the hasSpawned attribute
        // Cannot do that beforehand because of the double ckeck for sexual maturity
        for(School school : getSchoolSet().getSchools()) {
            school.incrementAge();
        }

    }

    /** Normalize season in the case of classical Osmose run */
    protected void normSeason() {

        for (int iSpec = 0; iSpec < getNSpecies(); iSpec++) {

            int length = seasonSpawning[iSpec].length;

            // no normalisation done if length == 1 (assumes
            // evenly distributed reproduction
            if (length == 1) {
                continue;
            }

            // If time series if of length nStep/year (i.e. 24 for instance)
            // one single normalisation is made for the series
            if (length == getConfiguration().getNStepYear()) {

                double sum = 0;

                // computes the sum over the vector
                for (double val : seasonSpawning[iSpec]) {
                    sum += val;
                }

                // if the sum is not 0 and if the sum different than 1, normalisation
                if ((sum > 0) && (sum != 1)) {
                    for (int cpt = 0; cpt < length; cpt++) {
                        seasonSpawning[iSpec][cpt] /= sum;
                    }
                }
            }

            // If the lenght of the time series is > nstepYear (i.e. values by years)
            else if (length > getConfiguration().getNStepYear()) {

                int start = 0;
                int end = getConfiguration().getNStepYear();

                // number of years = length / nstepyear. For instance, if length=48, nstep year=
                // 24, nyears = 2
                int nyears = length / getConfiguration().getNStepYear();

                // Loop over the years
                for (int iyear = 0; iyear < nyears; iyear++) {

                    double sum = 0;

                    // computes the sum
                    for (int cpt = start; cpt < end; cpt++) {
                        sum += seasonSpawning[iSpec][cpt];
                    }

                    // if the sum is not 0 and if the sum different than 1, normalisation
                    if ((sum > 0) && (sum != 1)) {
                        for (int cpt = start; cpt < end; cpt++) {
                            seasonSpawning[iSpec][cpt] /= sum;
                        }
                    }

                    // increment of the start/end indexes
                    end += getConfiguration().getNStepYear();
                    start += getConfiguration().getNStepYear();

                } // end of year for loop
            } // end of if condition on length
        } // end of species loop
    } // end of method

    /** Normalize season in the case of classical Osmose run */
    protected void bioenSeason() {

        for (int iSpec = 0; iSpec < getNSpecies(); iSpec++) {

            int length = seasonSpawning[iSpec].length;

            // no normalisation done if length == 1 (assumes
            // evenly distributed reproduction
            if (length == 1) {
                continue;
            }

            // If time series if of length nStep/year (i.e. 24 for instance)
            // one single normalisation is made for the series
            if (length == getConfiguration().getNStepYear()) {

                double sum = 0;

                // computes the sum over the vector
                for (double val : seasonSpawning[iSpec]) {
                    sum += val;
                }

                // if the sum is not 0 and if the sum different than 1, normalisation
                if ((sum > 0) && (sum != 1)) {
                    for (int cpt = 0; cpt < length; cpt++) {
                        seasonSpawning[iSpec][cpt] /= sum;
                    }
                }
            }

            // If the lenght of the time series is > nstepYear (i.e. values by years)
            else if (length > getConfiguration().getNStepYear()) {

                int start = 0;
                int end = getConfiguration().getNStepYear();

                // number of years = length / nstepyear. For instance, if length=48, nstep year=
                // 24, nyears = 2
                int nyears = length / getConfiguration().getNStepYear();

                // Loop over the years
                for (int iyear = 0; iyear < nyears; iyear++) {

                    double sum = 0;

                    // computes the sum
                    for (int cpt = start; cpt < end; cpt++) {
                        sum += seasonSpawning[iSpec][cpt];
                    }

                    // if the sum is not 0 and if the sum different than 1, normalisation
                    if ((sum > 0) && (sum != 1)) {
                        for (int cpt = start; cpt < end; cpt++) {
                            seasonSpawning[iSpec][cpt] /= sum;
                        }
                    }

                    // increment of the start/end indexes
                    end += getConfiguration().getNStepYear();
                    start += getConfiguration().getNStepYear();

                } // end of year for loop
            } // end of if condition on length
        } // end of species loop
    } // end of method

    protected double getSeason(int iStepSimu, Species species) {

        int iSpec = species.getSpeciesIndex();
        int length = seasonSpawning[iSpec].length;
        int iStep;
        if (length > getConfiguration().getNStepYear()) {
            iStep = iStepSimu;
        } else if (length == 1) {
            iStep = 0;
        } else {
            iStep = getSimulation().getIndexTimeYear();
        }
        
        if (getConfiguration().isBioenEnabled()) {
          return seasonSpawningBioen[iSpec][iStep];
        }
        
        return seasonSpawning[iSpec][iStep];
    }

    public double getSeedingBiomass(int i) {
        return this.seedingBiomass[i];
    }

    public double getSexRatio(int i) {
        return this.sexRatio[i];
    }

    public int getYearSeading() {
        return this.yearMaxSeeding;
    }

    public double getBeta(int i) {
        return this.beta[i];
    }

    /** Normalize season in the case of Osmose Bioen run */
    protected void normSeasonBioen() {

        // Computes the indexes that will be used for the normalisation
        for (int iSpec = 0; iSpec < getNSpecies(); iSpec++) {

            // length of the seasonspawning vector
            int length = seasonSpawning[iSpec].length;

            // if no spawning time-series provided, assumes that
            // evenly distributed
            if (length == 1) {
                continue;
            }

            // Init the list of reproduction start and end events
            ArrayList<Integer> startIndex = new ArrayList<>();
            ArrayList<Integer> endIndex = new ArrayList<>();

            // Array containing the normalized season spawning.
            double[] seasonSpawningTemp;

            if (length == getConfiguration().getNStepYear()) {
                // If nstep == nstepyear, seasonal variable.
                // It is duplicated 3 times, in order to facilitate
                // the normalisation along winter months
                seasonSpawningTemp = new double[3 * length];
                for (int k = 0; k < 3; k++) {
                    for (int p = 0; p < length; p++) {
                        seasonSpawningTemp[k * length + p] = seasonSpawning[iSpec][p];
                    }
                }
            } else {
                // if nsteps > nstep year, full copy is made.
                seasonSpawningTemp = new double[length];
                for (int p = 0; p < length; p++) {
                    seasonSpawningTemp[p] = seasonSpawning[iSpec][p];
                }
            }

            // loop over all the time-steps of the temporary vector
            for (int i = 0; i < seasonSpawningTemp.length; i++) {
                if (seasonSpawningTemp[i] > 0) {
                    // when the spawning is 1, reproduction event.
                    startIndex.add(i);
                    // loop over the season spawning index until end of vector or end of season
                    while ((i < length) && (seasonSpawningTemp[i] > 0)) {
                        i++;
                    }
                    endIndex.add(i);
                } // end of spawning test
                i++;
            }

            int nEvents = startIndex.size();
            for (int i = 0; i < nEvents; i++) {

                double sum = 0;
                int start = startIndex.get(i);
                int end = endIndex.get(i);

                for (int p = start; p < end; p++) {
                    sum += seasonSpawningTemp[p];
                }

                if (sum != 1) {
                    for (int p = start; p < end; p++) {
                        seasonSpawningTemp[p] /= sum;
                    }
                } // end of norm test

            } // end of loop on normalisation events

            if (length == getConfiguration().getNStepYear()) {
                for (int p = 0; p < getConfiguration().getNStepYear(); p++) {
                    // take the middle of the series, which insures continuity over winter months
                    seasonSpawning[iSpec][p] = seasonSpawningTemp[p + getConfiguration().getNStepYear()];
                }
            } else {
                for (int p = 0; p < length; p++) {
                    seasonSpawning[iSpec][p] = seasonSpawningTemp[p];
                }
            }

        } // end of species loop
    }

    /** Reproduction run method in case the genetic module is enabled.
    */
    public void run_genet() {

        int cpt;
        double school_spawners = 0;

        // Loop over all species
        for (cpt = 0; cpt < this.getNSpecies(); cpt++) {

            // If the species does not reproduce, then
            // nothing is done here.
            if (!reproduce[cpt]) {
                continue;
            }

            // reset the weighted random mean
            weight_rand.reset();

            Species species = getSpecies(cpt);
            List<School> schoolset = getSchoolSet().getSchools(species);

            // compute number of eggs to be released
            double season = getSeason(getSimulation().getIndexTimeSimu(), species);

            // total number of eggs for the species
            double total_species_eggs = 0.d;

            // if the seeding biomass is not null, loop over sexually mature schools
            for (School school : schoolset) {

                if (school.getSpecies().isSexuallyMature(school)) {
                    // get the school spawners, either in grams (for ovoviviparity)
                    // or as number of individuals
                    school_spawners = spawnerInterface[cpt].getSpawner(school);
                    // convert spawners into number of eggs
                    double school_nEgg = sexRatio[cpt] * beta[cpt] * season * school_spawners;
                    // increment the total number of eggs
                    total_species_eggs += school_nEgg;
                    weight_rand.add(school_nEgg, school);
                    // if a positive number of eggs, indicate the school has spawned
                    if (school_nEgg > 0) school.setHasSpawned(true);
                }

            } // end of loop over the school that belong to species i

            if((total_species_eggs == 0) && (getSimulation().getIndexTimeSimu() < yearMaxSeeding)) {
                // if the total number of eggs is 0, i.e no mature individuals
                // we artificially create individuals based on the seeding biomass
                // in this case, weight_rand is never used.
                double seeding_nEggs = sexRatio[cpt] * beta[cpt] * season * seedingInterface[cpt].getSeeding(cpt);
                this.create_reproduction_schools(cpt, seeding_nEggs, false, weight_rand);
            } else {
                // if the total number of eggs is not 0, then we create schools with genotype transmission
                boolean transmitGenotype = (this.getSimulation().getIndexTimeSimu() >= this.dateGenoTransmission) ? true : false;
                this.create_reproduction_schools(cpt, total_species_eggs, transmitGenotype, weight_rand);
            }
        } // end of species loop

        // Finally, we increment the age and set the hasSpawned attribute
        // Cannot do that beforehand because of the double ckeck for sexual maturity
        for(School school : getSchoolSet().getSchools()) {
            school.incrementAge();
        }

    }

    protected void create_reproduction_schools(int speciesIndex, double nEgg, boolean transmit_genotype, WeightedRandomDraft<School> rand_draft) {
        // nschool increases with time to avoid flooding the simulation with too many schools since the beginning
        //nSchool = Math.min(getConfiguration().getNSchool(i), nSchool * (getSimulation().getIndexTimeSimu() + 1) / (getConfiguration().getNStepYear() * 10));

        // if the number of eggs is 0, nothing is done
        if (nEgg == 0.d) {
            return;
        }

        // lay age class zero
        int nSchool = getConfiguration().getNSchool(speciesIndex);
        Species species = getSpecies(speciesIndex);

        // do nothing, zero school
        if (nEgg < nSchool) {

            School school0 = new School(species, nEgg);
            school0.instance_genotype(this.getRank());
            if (transmit_genotype) {
                School parent_a = rand_draft.next();
                School parent_b = rand_draft.next();
                school0.getGenotype().transmit_genotype(parent_a.getGenotype(), parent_b.getGenotype());
            } else {
                school0.getGenotype().init_genotype();
            }
            getSchoolSet().addReproductionSchool(school0);
        } else if (nEgg >= nSchool) {

            for (int s = 0; s < nSchool; s++) {
                School school0 = new School(species, nEgg / nSchool);
                school0.instance_genotype(this.getRank());
                if (transmit_genotype) {
                    School parent_a = rand_draft.next();
                    School parent_b = rand_draft.next();
                    school0.getGenotype().transmit_genotype(parent_a.getGenotype(), parent_b.getGenotype());
                } else {
                    school0.getGenotype().init_genotype();
                }
                getSchoolSet().addReproductionSchool(school0);
            }

        } // end of test on nEgg
    }  // end of method


    public double getSeedingAbundance(int i) {
        return seedingAbundance[i];
    }

}
