# Library loading

```{literalinclude} _static/package_loading.R
:language: R
```

```{eval-rst}
.. program-output:: Rscript rosmose/_static/package_loading.R
```
