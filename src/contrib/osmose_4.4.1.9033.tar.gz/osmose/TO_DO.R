

To implement: simulation.time.nstep in run_osmose

movement maps weighted by area 

processing of land-based predators

osmose_initialize(what=c("focal", "background")

Nico: 

when passing parameters from command line:
species.file OK, it is read relative to main config file
simulation.restart.file NOT OK, read from getwd()

Ricardo:

# FORCING

Physical forcing available to every method: T-dependent growth.

# INITIALISATION

GW = r*SW

# GROWTH

Three stages for growth.
Only 1 message per growth type.

# BIOENERGETICS

introduce Tmin, Tmax, Topt, T05?
reparameterise c_t
generalise EnergyBudget

# REPRODUCTION

VIVIPARES: 
integer release, use (a,b) for length, no spherical approximation


- initialisation uses: s50, l50, l75, m0
  - implement 2,3, 4 and 5.
1. probabilistic linear maturation norm: S50, S75, m
2. deterministic linear maturation norm; S50, m, 
3. probabilistic ojive: L75, L50, 
4. deterministic: L50
5. deterministic: A50

species.reproduction.strategy.sp0 = iteroparous/semelparous
species.reproduction.mode.sp0 = oviparity/viviparity
species.reproduction.breeding.type.sp0 = capital/income ??
species.reproduction.gestation.time.sp0 = 1 # in years

reproduction.season.file.sp0 = file # relative distribution of spawning (mating for vivipares)

# MORTALITY

Post-reproduction mortality
All outputs standardise to 1/year?

# OUTPUTS

Fix TL outputs

# Improvements

Do not set the movement.lastage.spX for the last age map, or check that it matches lifespan?

# PARAMETERS

movement.netcdf.enable -> species.movement.ncdf.enabled
species.first.feeding.age.sp




