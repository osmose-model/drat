(dat)=

# Datarmor use

```{eval-rst}
.. include:: datarmor/packload.txt
```

```{eval-rst}
.. include:: datarmor/runpar.txt
```
