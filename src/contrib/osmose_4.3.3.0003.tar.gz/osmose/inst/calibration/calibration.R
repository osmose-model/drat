#!/usr/bin/env Rscript
#  
# Arguments for the script
#
# --calibration.control=file : options are taken from 'file' (no spaces in 'file' are allowed).
# --test                     : boolean, is it a test? Does not run OSMOSE if is a test (save time!).
# --run_model=file           : 'file' is sourced to find the 'run_model' function.
# --ncores=n                 : 'n' is the number of cores. Better to be passed automatically from PBS script.
# --mpi                      : Use MPI.
# --replicates=n             : 'n' is the number of replicates, controlled from the 'calibrar' package.

if(!exists("args")) args = commandArgs(trailingOnly=TRUE)

library("osmose")
library("calibrar")

control_file   = .get_command_argument(args, "calibration.control", default=NULL)
if(is.null(control_file)) stop("A control file must be specified ('--calibration.control=file')")
is_a_test      = .get_command_argument(args, "test")
run_model_file = .get_command_argument(args, "run_model", default="run_model.R")
ncores         = .get_command_argument(args, "ncores", default=1)
MPI            = .get_command_argument(args, "mpi")
replicates     = .get_command_argument(args, "replicates", default=1)

control = .read_configuration(control_file)

# check for mandatory arguments
msg = "You must provide a '%s' argument in '%s'"
if(is.null(control$data_path)) stop(sprintf(msg, "data_path", control_file))
if(is.null(control$osmose)) stop(sprintf(msg, "osmose", control_file))

# check for some defaults if missing
if(is.null(control$verbose)) control$verbose = TRUE
control$parallel = (ncores > 1)

conf = read_osmose("master/osmose-calibration.osm")
model = get_par(conf, "output.file.prefix")

# explicit some variables
data_path = control$data_path
verbose   = control$verbose
osmose    = control$osmose
parallel  = control$parallel
method    = control$method

source(run_model_file)
if(!exists("run_model", mode="function"))
  stop(sprintf("We couldn't find the 'run_model' function in '%s'.", run_model_file))

# we are fixing the following names, 'cause too many arguments.  
setup = calibration_setup(file = sprintf("osmose-%s-calibration_settings.csv", model))

par_guess = read_osmose(input=sprintf("osmose-%s-parguess.osm", model))
par_min   = read_osmose(input=sprintf("osmose-%s-parmin.osm", model))
par_max   = read_osmose(input=sprintf("osmose-%s-parmax.osm", model))
par_phase = read_osmose(input=sprintf("osmose-%s-parphase.osm", model))

# read observed data
observed = calibration_data(setup=setup, path=data_path, verbose=verbose)

# create objective function
osmose = file.path("..", osmose) # to make it relative to master
objfn = calibration_objFn(model=run_model, setup=setup, observed=observed, 
                          conf=conf, osmose=osmose, is_a_test=is_a_test)

if(!is.null(control$master)) {
  if(control$master!="master") {
    msg0 = "This script relays on using a 'master' folder right here. \nRename the folder '%s' to master and put it here."
    stop(sprintf(msg0, control$master))
  }  
}

if(!is.null(control$run)) {
  if(control$run!="../.run") {
    msg0 = "This script relays on using an specific 'run' folder.. \nIgnoring the line 'run = %s' from '%s'."
    warning(sprintf(msg0, control$run, control_file))
  }  
}

restart_file = if(is_a_test) "osmose-test" else sprintf("osmose-%s", model)
control$master = "master" # directory that will be copied
control$run = "../.run"   # run directory
control$restart.file = restart_file # name of the restart file
control$ncores = ncores # the actual number of cores you have

if(isTRUE(parallel)) {
  
  if(!isTRUE(MPI)) {
    library("doParallel")
    cl = makeCluster(control$nCores)
    registerDoParallel(cl)
  } else {
    library("doSNOW")
    cl = makeCluster()
    registerDoSNOW(cl)
  }
  
  clusterExport(cl, c("conf", "is_a_test", "osmose"))
  clusterEvalQ(cl, library("calibrar"))
  clusterEvalQ(cl, library("osmose"))
  
}

# launch the calibration!
opt = calibrate(par=par_guess, fn=objfn, method=method,
                lower=par_min, 
                upper=par_max, 
                phases=par_phase,
                replicates=replicates,
                control=control)

# tidy up
if(isTRUE(parallel)) stopCluster(cl)
