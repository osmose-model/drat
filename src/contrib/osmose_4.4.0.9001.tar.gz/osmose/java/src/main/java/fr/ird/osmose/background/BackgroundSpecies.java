/*
 *
 * OSMOSE (Object-oriented Simulator of Marine Ecosystems)
 * http://www.osmose-model.org
 *
 * Copyright (C) IRD (Institut de Recherche pour le Développement) 2009-2020
 *
 * Osmose is a computer program whose purpose is to simulate fish
 * populations and their interactions with their biotic and abiotic environment.
 * OSMOSE is a spatial, multispecies and individual-based model which assumes
 * size-based opportunistic predation based on spatio-temporal co-occurrence
 * and size adequacy between a predator and its prey. It represents fish
 * individuals grouped into schools, which are characterized by their size,
 * weight, age, taxonomy and geographical location, and which undergo major
 * processes of fish life cycle (growth, explicit predation, additional and
 * starvation mortalities, reproduction and migration) and fishing mortalities
 * (Shin and Cury 2001, 2004).
 *
 * Contributor(s):
 * Yunne SHIN (yunne.shin@ird.fr),
 * Morgane TRAVERS (morgane.travers@ifremer.fr)
 * Ricardo OLIVEROS RAMOS (ricardo.oliveros@gmail.com)
 * Philippe VERLEY (philippe.verley@ird.fr)
 * Laure VELEZ (laure.velez@ird.fr)
 * Nicolas BARRIER (nicolas.barrier@ird.fr)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation (version 3 of the License). Full description
 * is provided on the LICENSE file.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
package fr.ird.osmose.background;

import fr.ird.osmose.Configuration;
import fr.ird.osmose.Osmose;
import fr.ird.osmose.util.OsmoseLinker;
import fr.ird.osmose.util.timeseries.ByClassTimeSeries;
import fr.ird.osmose.util.timeseries.ByRegimeTimeSeries;
import fr.ird.osmose.util.timeseries.ForcingTimeSeries;

import java.io.IOException;
import ucar.ma2.InvalidRangeException;
import fr.ird.osmose.ISpecies;

/**
 *
 * @author nbarrier
 */
public class BackgroundSpecies extends OsmoseLinker implements ISpecies {

///////////////////////////////
// Declaration of the variables
///////////////////////////////

    private interface Proportion {
        double getProportion(int iClass, int step);
    }


    private final Proportion proportion;

    /**
     * Index of the species. [0 : number of background - 1]
     */
    private final int fileindex;

    /**
     * Name of the species. Parameter <i>species.name.sp#</i>
     */
    private final String name;

    /**
     * Allometric parameters. Parameters
     * <i>species.length2weight.condition.factor.sp#</i> and
     * <i>species.length2weight.allometric.power.sp#</i>
     */
    private final float c, bPower;

    /**
     * Trophic Level.
     *
     * @todo Use TL by stage instead?
     */
    private final float[] trophicLevel;

    private final float[] length;

    private final float[] classProportion;

    private final float[] age;

    private final int[] ageDt;

    private final int nClass;

    private final ByClassTimeSeries timeSeries;

    private final int index;
    private final int offset;

    private double betaBioen;

    private double[][] biomass;

    /**
     * Constructor of background species.
     *
     * @param fileindex
     * @param index
     * @throws java.io.IOException
     * @throws ucar.ma2.InvalidRangeException
     */
    public BackgroundSpecies(int fileindex, int index) throws IOException, InvalidRangeException {

        Configuration cfg = Osmose.getInstance().getConfiguration();

        boolean isOk = true;
        String message = "";

        this.offset = cfg.getNSpecies();
        this.index = index + this.offset;

        // Initialiaze the index of the Background species
        this.fileindex = fileindex;

        if(getConfiguration().isBioenEnabled()) {
            String key = String.format("species.beta.sp%d", fileindex);
            betaBioen = cfg.getDouble(key);
        }

        // Initialization of parameters
        name = cfg.getString("species.name.sp" + fileindex).replaceAll("_", "").replaceAll("-", "");

        nClass = cfg.getInt("species.nclass.sp" + fileindex);

        // Reads allometric variables to obtain weight from size
        c = cfg.getFloat("species.length2weight.condition.factor.sp" + fileindex);
        bPower = cfg.getFloat("species.length2weight.allometric.power.sp" + fileindex);

        trophicLevel = cfg.getArrayFloat("species.trophic.level.sp" + fileindex);

        age = cfg.getArrayFloat("species.age.sp" + fileindex);
        ageDt = new int[age.length];
        for (int i = 0; i < age.length; i++) {
            ageDt[i] = (int) age[i] * getConfiguration().getNStepYear();
        }

        if (cfg.canFind("species.size.proportion.file.sp" + fileindex)) {

            String filename = cfg.getFile("species.size.proportion.file.sp" + fileindex);
            this.timeSeries = new ByClassTimeSeries();
            this.timeSeries.read(filename);
            length = this.timeSeries.getClasses();
            this.classProportion = null;
            proportion = (iClass, i) -> this.proportionFile(iClass, i);

        } else {

            this.timeSeries = null;

            // Proportion of the different size classes
            classProportion = cfg.getArrayFloat("species.size.proportion.sp" + fileindex);
            // Get the array of species length
            length = cfg.getArrayFloat("species.length.sp" + fileindex);

            if (classProportion.length != nClass) {
                message = String.format("Length of species.size.proportion.sp%d is "
                        + "not consistent with species.nclass.cp%d", fileindex, fileindex);
                isOk = false;
            }

            // check that the classProportion sums to 1.
            float sum = 0.f;
            for (int i = 0; i < classProportion.length; i++) {
                sum += classProportion[i];
            }

            if (sum != 1.f) {
                message = String.format("species.size.proportion.sp%d must sum to 1.0", fileindex);
                isOk = false;
            }

            proportion = (iClass, i) -> this.proportionConst(iClass, i);

        }

        if (trophicLevel.length != nClass) {
            message = String.format("Length of species.trophic.level.sp%d is "
                    + "not consistent with species.nclass.cp%d", fileindex, fileindex);
            isOk = false;
        }

        if (age.length != nClass) {
            message = String.format("Length of species.age.sp%d is "
                    + "not consistent with species.nclass.cp%d", fileindex, fileindex);
            isOk = false;
        }

        if (length.length != nClass) {
            message = String.format("Length of species.length.sp%d is "
                    + "not consistent with species.nclass.cp%d", fileindex, fileindex);
            isOk = false;
        }

        if (!isOk) {
          // This is only throwing the last message!
          error(message, new IOException());
        }

        String keyMul = String.format("species.multiplier.sp%s", fileindex);
        String keyMulLog = String.format("species.multiplier.log.sp%s", fileindex);

        // test if only one of the two values exists
        if (!getConfiguration().isNull(keyMulLog) && !getConfiguration().isNull(keyMul)) {
            message = String.format("Both %s and %s parameters are defined. Choose only one.\n", keyMulLog, keyMul);
            error(message, new Exception());
        }

        double multiplier = 1.d;

        if (!getConfiguration().isNull(keyMulLog)) {
            multiplier = Math.exp(getConfiguration().getFloat("species.multiplier.log.sp" + fileindex));
            warning("Biomass for background group " + fileindex + " will be multiplied by " + multiplier
                    + " accordingly to parameter "
                    + getConfiguration().printParameter("species.multiplier.log.sp" + fileindex));
        } else {
            multiplier = getConfiguration().getFloat("species.multiplier.sp" + fileindex);
            warning("Biomass for background group " + fileindex + " will be multiplied by " + multiplier
                    + " accordingly to parameter "
                    + getConfiguration().printParameter("species.multiplier.sp" + fileindex));
        }

        // Reading the biomass time-series. So far, it is a yearly time-series
        // to see if we update that to any kind of time-series
        String keyVal = "species.biomass.sp" + fileindex;
        String keyShift = "species.biomass.nsteps.year.sp" + fileindex;
        //ByRegimeTimeSeries biomassSeries = new ByRegimeTimeSeries(keyShift, keyVal);
        ForcingTimeSeries biomassSeries = new ForcingTimeSeries(keyShift, keyVal);
        biomassSeries.init();

        // Combine yearly time-series and size-proportion to reconstruct
        // by time/ by size time series of biomass.
        double[] biomassVect = biomassSeries.getValues();
        biomass = new double[biomassVect.length][nClass];
        for (int t = 0; t < biomassVect.length; t++) {
            for (int s = 0; s < nClass; s++) {
                biomass[t][s] = multiplier * biomassVect[t] * proportion.getProportion(s, t);
            }
        }
    }

    public double getBiomass(int timeStep, int iClass) {
        return this.biomass[timeStep][iClass];
    }

    /** Get the species index as defined in the file.
     *
     * @return
     */
    @Override
    public int getFileSpeciesIndex() {
        return this.fileindex;
    }

    /**
     * Return the global index of the species.
     *
     * Index between [Nsp, Nbkg - 1] if applyOffset is True
     *
     * @return
     */
    @Override
    public int getSpeciesIndex() {
        return this.index;
    }

    /**
     * Returns the trophic level of the current background species.
     *
     * @param iClass
     * @todo Do this by class?
     * @return
     */
    public float getTrophicLevel(int iClass) {
        return this.trophicLevel[iClass];
    }

    /**
     * Computes the weight, in gram, corresponding to the given length, in
     * centimeter.
     *
     * @param length, the length in centimeter
     * @return the weight in gram for this {@code length}
     */
    public float computeWeight(float length) {
        return (float) (c * (Math.pow(length, bPower)));
    }

    public double getBetaBioen() {
        return this.betaBioen;
    }

    /**
     * Returns the name of the background species.
     *
     * @return The species name
     */
    @Override
    public String getName() {
        return name;
    }

    public float getLength(int iClass) {
        return this.length[iClass];
    }

    /** Get the class proportion of a given class at
     * a given step.
     *
     * Call a different method depending on whether constant
     * of by-class time series are provided.
     *
     * @param iClass
     * @param step
     * @return
     */
    public double getProportion(int iClass, int step) {
        return proportion.getProportion(iClass, step);
    }

    /**
     * Returns the proportion of a given class if varying over time.
     *
     * Must be defined in a {@link ByClassTimeSeries()} object.
     *
     * @param iClass
     * @param step Time step (not used)
     * @return
     */
    private double proportionFile(int iClass, int step) {
        return this.timeSeries.getValue(step, iClass);
    }

    /** Returns the proportion of a given class if constant over time.
     *
     * @param iClass
     * @param step Time step (not used)
     * @return
     */
    private double proportionConst(int iClass, int step) {
        return this.classProportion[iClass];
    }

    public float getAge(int iClass) {
        return this.age[iClass];
    }

    public int getAgeDt(int iClass) {
        return this.ageDt[iClass];
    }

    public int getNClass() {
        return this.nClass;
    }

}
