.. _misc:

Miscellaneous
*************************

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   misc/datarmor
..    misc/weights_calc
