Submodels
==========================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   submodel/energy_uptake.rst
   submodel/maintenance.rst
   submodel/new_tissue.rst
   submodel/maturation.rst
   submodel/reproduction.rst
   submodel/mortality.rst
