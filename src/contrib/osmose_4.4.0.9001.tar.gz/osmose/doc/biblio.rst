
Bibliography
##########################

.. bibliography:: _static/biblio.bib
    :style: alpha
    :all:
