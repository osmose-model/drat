Resource update
++++++++++++++++

The resource update consists in updating the resource forcings by reading the proper time-steps in the input NetCDF files. This updates is done for both resource and background species.
