.. include:: <s5defs.txt>
.. role:: red
.. |os| replace:: OSMOSE
.. |jos| replace:: OSMOSE Java
.. |dat| replace:: Datarmor
.. |nc| replace:: NetCDF
.. |csv| replace:: CSV
.. |orc| replace:: ORCA
.. |cal| replace:: :samp:`calibrar`
.. |ros| replace:: :samp:`osmose`
.. |cman| replace:: Osmose Configuration Manager
