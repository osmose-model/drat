# OSMOSE (Object-oriented Simulator of Marine Ecosystems)
# http://www.osmose-model.org
#
# Copyright (C) IRD (Institut de Recherche pour le Développement) 2009-2020
#
# Osmose is a computer program whose purpose is to simulate fish
# populations and their interactions with their biotic and abiotic environment.
# OSMOSE is a spatial, multispecies and individual-based model which assumes
# size-based opportunistic predation based on spatio-temporal co-occurrence
# and size adequacy between a predator and its prey. It represents fish
# individuals grouped into schools, which are characterized by their size,
# weight, age, taxonomy and geographical location, and which undergo major
# processes of fish life cycle (growth, explicit predation, additional and
# starvation mortalities, reproduction and migration) and fishing mortalities
# (Shin and Cury 2001, 2004).
#
# Contributor(s):
# Yunne SHIN (yunne.shin@ird.fr),
# Morgane TRAVERS (morgane.travers@ifremer.fr)
# Ricardo OLIVEROS RAMOS (ricardo.oliveros@gmail.com)
# Philippe VERLEY (philippe.verley@ird.fr)
# Laure VELEZ (laure.velez@ird.fr)
# Nicolas BARRIER (nicolas.barrier@ird.fr)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation (version 3 of the License). Full description
# is provided on the LICENSE file.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

# osmose package: Modelling Marine Exploited Ecosystems

#' OSMOSE: Modelling Exploited Marine Ecosystems
#' 
#' \if{html}{\figure{sticker_osmose.png}{options: align='right' alt='logo' width='150'}}
#' 
#' OSMOSE is a multispecies and Individual-based model (IBM) which 
#' focuses on fish species. This model assumes opportunistic predation based on 
#' spatial co-occurrence and size adequacy between a predator and its prey 
#' (size-based opportunistic predation). It represents fish individuals grouped 
#' into schools, which are characterized by their size, weight, age, taxonomy and 
#' geographical location (2D model), and which undergo major processes of fish 
#' life cycle (growth, explicit predation, natural and starvation mortalities, 
#' reproduction and migration) and a fishing mortality distinct for each species 
#' (Shin and Cury 2001, 2004). The model needs basic parameters that are often 
#' available for a wide range of species, and which can be found in FishBase 
#' for instance. This package provides tools to build a model and run simulations
#' using the OSMOSE model. See the 
#' \href{http://www.osmose-model.org/}{Official website} for more details.
#' 
#' \code{osmose} package is well documented by help descriptions, demos and 
#' vignettes.
#' 
#' \strong{Demo scripts:}
#' 
#' \code{# Check all the available topics}
#' 
#' \code{demo(package = "osmose")}
#' 
#' \code{# Select and run one of the topics (e.g. osmose.config_class)}
#' 
#' \code{demo(package = "osmose", topic = "osmose.config_class")}
#' 
#' \strong{Vignettes:}
#' 
#' \code{# Check all the available topics}
#' 
#' \code{vignette(package = "osmose")}
#' 
#' \code{# Select and run one of the topics (e.g. create_run_read)}
#' 
#' \code{vignette(package = "osmose", topic = "create_run_read")}
#' 
#' 
#' @name osmose-package
#' @aliases osmose-package osmose
#' @docType package
#' @author Yunne-Jai Shin
#' @author Ricardo Oliveros-Ramos 
#' @author Laure Velez
#' @author Criscely Luján
#' @author Philippe Verley
#' @author Maintainer: Nicolas Barrier <nicolas.barrier@ird.fr>
#' @references \href{http://www.osmose-model.org/}{Official website}
#' \href{https://documentation.osmose-model.org/index.html}{Documentation website}
#' @keywords modelling marine ecosystems
NULL