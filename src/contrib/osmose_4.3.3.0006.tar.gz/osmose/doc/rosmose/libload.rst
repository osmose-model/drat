Library loading
+++++++++++++++++++

.. literalinclude:: _static/package_loading.R
    :language: R

.. program-output:: Rscript rosmose/_static/package_loading.R
