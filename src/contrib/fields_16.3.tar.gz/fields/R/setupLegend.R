#
# fields  is a package for analysis of spatial data written for
# the R software environment.
# Copyright (C) 2024 Colorado School of Mines
# 1500 Illinois St., Golden, CO 80401
# Contact: Douglas Nychka,  douglasnychka@gmail.com,
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2
##END HEADER
setupLegend<- function( horizontal = FALSE,
                        legend.shrink = 0.9, 
                        legend.width = 1.2, 
                        legend.mar = ifelse(horizontal, 3.1, 5.1)
){
  # save current graphics settings
   
  temp <- imageplot.setup(add = FALSE, 
                          legend.shrink = legend.shrink, 
                          legend.width = legend.width ,
                          legend.mar= legend.mar, 
                          horizontal = horizontal,
                          bigplot = NULL,
                          smallplot = NULL)
  Info<- list(    smallplot = temp$smallplot, 
              legend.shrink = legend.shrink, 
                legend.mar  = legend.mar, 
               legend.width = legend.width ,
                 horizontal = horizontal)
#oldPar =  par(no.readonly = TRUE) )
  par(plt = temp$bigplot)
  
  return( Info)
}

