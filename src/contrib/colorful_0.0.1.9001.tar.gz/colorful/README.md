# colorful
Some miscelaneous graphic tools using base R (graphics).
