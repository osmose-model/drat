/*
 * OSMOSE (Object-oriented Simulator of Marine ecOSystems Exploitation)
 * http://www.osmose-model.org
 * 
 * Copyright IRD (Institut de Recherche pour le Développement) 2013
 * 
 * Contributor(s):
 * Yunne SHIN (yunne.shin@ird.fr),
 * Morgane TRAVERS (morgane.travers@ifremer.fr)
 * Philippe VERLEY (philippe.verley@ird.fr)
 *
 * This software is a computer program whose purpose is to simulate fish
 * populations and their interactions with their biotic and abiotic environment.
 * OSMOSE is a spatial, multispecies and individual-based model which assumes
 * size-based opportunistic predation based on spatio-temporal co-occurrence
 * and size adequacy between a predator and its prey. It represents fish
 * individuals grouped into schools, which are characterized by their size,
 * weight, age, taxonomy and geographical location, and which undergo major
 * processes of fish life cycle (growth, explicit predation, natural and
 * starvation mortalities, reproduction and migration) and fishing mortalities
 * (Shin and Cury 2001, 2004).
 * 
 * This software is governed by the CeCILL-B license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL-B
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL-B license and that you accept its terms.
 */
package fr.ird.osmose.util.filter;

import fr.ird.osmose.Osmose;
import java.util.Arrays;
import java.util.HashSet;

/**
 *
 * @author pverley
 */
public class FilteredSets {

    /**
     * Given a subset, the extract method creates a sub subset thanks to
     * the CommunityFilter.
     * 
     * @param <T>
     * @param set
     * @param filter
     * @return
     */
    public static <T> FilteredSet<T> subset(FilteredSet<T> set, IFilter<? super T>[] filters) {

        FilteredSet<T> subset = new FilteredSet(set, filters);
        refresh(subset);
        return subset;
    }

    public static <T> FilteredSet<T> subset(FilteredSet<T> set, IFilter<? super T> filter) {
        return subset(set, new IFilter[]{filter});
    }

    public static <T> void refresh(FilteredSet<T> set) {
        if (null != set.getParent()) {
            set.clear();
            IFilter<? super T>[] filters = set.getFilters();
            for (T member : set.getParent()) {
                boolean accept = true;
                if (filters != null) {
                    for (IFilter<? super T> filter : filters) {
                        accept = accept && filter.accept(member);
                        if (!accept) {
                            break;
                        }
                    }
                    if (accept) {
                        set.add(member);
                    }
                }
            }
        } else {
            //throw new NullPointerException("Community's parent is null");
        }
    }

    public static <T> FilteredSet<T> intersect(FilteredSet<T> subset1, FilteredSet<T> subset2) {

        HashSet<T> set = new HashSet();
        set.addAll(subset1);
        set.addAll(subset2);

        FilteredSet<T> merged = new FilteredSet();
        merged.addAll(set);

        HashSet<IFilter<? super T>> filters = new HashSet();
        filters.addAll(Arrays.asList(subset1.getFilters()));
        filters.addAll(Arrays.asList(subset2.getFilters()));

        return FilteredSets.subset(merged, filters.toArray(new IFilter[filters.size()]));
    }

    public static Osmose getOsmose() {
        return Osmose.getInstance();
    }
}
