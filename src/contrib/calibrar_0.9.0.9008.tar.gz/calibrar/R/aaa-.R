#' @importFrom foreach foreach %dopar%
NULL
#' @importFrom graphics abline points
NULL
#' @importFrom stats optim pnorm rexp rnorm rpois runif weighted.mean coef 
#' complete.cases filter lm na.omit predict sigma splinefun loess
NULL
#' @importFrom utils as.relistable read.csv relist write.csv head tail type.convert
NULL
#' @importFrom stringr str_split str_trim str_sub str_locate
NULL
#' @importFrom optimx Rcgmin bmchk grchk
NULL
#' @importFrom minqa bobyqa
NULL
