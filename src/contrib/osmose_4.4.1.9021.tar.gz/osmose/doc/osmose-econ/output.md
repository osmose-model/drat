# Output

Total profit

Total revenue

Total costs

Future prices

Scenarios: change harvest (`H_{i, t}`), change distribution of harvest over size classes, delete time trend (`\tau_{i}=0`), see what happens when consumers prefer larger or smaller fish (change `\beta_{i,s}`)...
