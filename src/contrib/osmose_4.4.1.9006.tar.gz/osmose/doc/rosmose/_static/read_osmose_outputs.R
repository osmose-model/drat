library("osmose")

data = read_osmose(path='output') 
