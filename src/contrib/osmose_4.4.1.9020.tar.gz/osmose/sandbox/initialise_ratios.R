


initialise_osmose(, type="predation_ratios")

#predation.predPrey.stage.structure = size

# inputs
predation.type.sp0 = planktivorous, piscivorous
predation.predPrey.stage.threshold.sp0 = 6,Lmat

# output
predation.predPrey.sizeRatio.max.sp0 = 80,6,2
predation.predPrey.sizeRatio.min.sp0 = 800,200,30


out = estimate_predation_ratios(type=c("planktivorous", "piscivorous", "predations"),
                          breaks=c(6, Lmat))

plot(out)
write_osmose(out, file="", append=TRUE)


predation.predPrey.sizeRatio.max.sp0 = 80,6,2
predation.predPrey.sizeRatio.min.sp0 = 800,200,30


