Fishing parameters (Osmose >= 4.2.0 & <= 4.2.0)
-----------------------------------------------------------

Between the 4.0.0 and 4.2.0 Osmose versions, a new way to implement fisheries is possible.

.. include:: fisheries/fisheries.txt
.. include:: fisheries/select.txt
.. include:: fisheries/time.txt
.. include:: fisheries/spatial.txt


