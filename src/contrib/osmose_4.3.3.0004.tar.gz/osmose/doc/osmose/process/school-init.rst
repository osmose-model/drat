School initialisation
++++++++++++++++++++++

The school initialisation process allows to reset some variables at the beginning of the time steps. For instant, the number of
dead individuals, the total ingestion of the school, etc.

Resource update
++++++++++++++++

The resource update consists in updating the resource forcings by reading the proper time-steps in the input NetCDF files. This updates is done for both resource and background species.
