#ifndef _ZZZ_H_
#define _ZZZ_H_

SEXP ore_init (void);

SEXP ore_done (void);

#endif
