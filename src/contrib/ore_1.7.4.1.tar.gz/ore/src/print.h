#ifndef _PRINT_H_
#define _PRINT_H_

SEXP ore_print_match (SEXP match, SEXP context_, SEXP width_, SEXP max_lines_, SEXP use_colour_);

#endif
