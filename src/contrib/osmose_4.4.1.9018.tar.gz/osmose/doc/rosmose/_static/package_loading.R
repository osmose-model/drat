require("osmose")

ls("package:osmose")
