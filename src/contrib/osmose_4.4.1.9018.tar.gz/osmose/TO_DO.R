

To implement: simulation.time.nstep in run_osmose

movement maps weighted by area 

processing of land-based predators

osmose_initialize(what=c("focal", "background")

Nico: when passing parameters from command line:
species.file OK, it is read relative to main config file
simulation.restart.file NOT OK, read from getwd()

Ricardo


- initialisation uses: s50, l50, l75, m0
  - implement 2,3, 4 and 5.
1. probabilistic linear maturation norm: S50, S75, m
2. deterministic linear maturation norm; S50, m, 
3. probabilistic ojive: L75, L50, 
4. deterministic: L50
5. deterministic: A50

- splitting of larval mortalities with clusters


osmose.user.

# OPTION 1
mortality.additional.larva.group.sp0 = smallpelagics, coastal
mortality.additional.larva.group.sp1 = smallpelagics, oceanic
mortality.additional.larva.group.sp2 = demersal, oceanic

# OPTION 2

# osmose.user chain is used only during the calibration

# activate interannual deviates (negative phase if FALSE)
calibration.mortality.additional.larval.deviate.active = TRUE
# use groups
calibration.mortality.additional.larva.rate.bygroup = TRUE
# activate base deviates (negative phase if FALSE)
calibration.mortality.additional.larval.residuals.active = TRUE
# use base deviates? If FALSE, set to 0 and active=FALSE
calibration.mortality.additional.larval.residuals.use = TRUE

mortality.additional.larva.rate.group.name.gr0 = fast
mortality.additional.larva.rate.group.species.gr0 = 0,1,2,4,7,9

osmose.user.additional.larva.rate.group.value.log10.gr0 = 15

osmose.user.additional.larva.rate.group.name.gr1 = slow
osmose.user.additional.larva.rate.group.value.log10.gr1 = 20
osmose.user.additional.larva.rate.group.species.gr1 = 0,1,2,3,4,5,6



osmose.user.additional.larva.rate.group.name.gr1 = spatial1
osmose.user.additional.larva.rate.group.value.log10.gr1 = 30
osmose.user.additional.larva.rate.group.species.gr1 = 0,1,2,4,7,9

osmose.user.additional.larva.rate.residual.sp0 = 47.17912
osmose.user.additional.larva.rate.residual.sp1 = 47.17912


I do not have larval mortalities, I assumme some groups and want to fit them,
so I reduce the number of larval mortalities.
Initialisation always give you some values.

I want equal mortalities: change residual guess to 0, if not found values, zero.


# Bioenergetics

introduce Tmin, Tmax, Topt, T05?
reparameterise c_t
generalise EnergyBudget


species.reproduction.strategy.sp0 = iteroparous/semelparous
species.reproduction.mode.sp0 = oviparity/viviparity
species.reproduction.breeding.type.sp0 = capital/income ??
species.reproduction.gestation.time.sp0 = 1 # in years

reproduction.season.file.sp0 = file # relative distribution of spawning (mating for vivipares)





