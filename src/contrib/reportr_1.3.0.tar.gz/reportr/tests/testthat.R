library(testthat)
library(reportr)

test_check("reportr")
