
# Auxiliar ----------------------------------------------------------------

#' Set values for a parameter list
#'
#' @param x The osmose.configuration list.
#' @param value The parameter value to replace.
#' @param ... Additional arguments
#'
#' @return The configuration list with parameter values changed.
#' @export
#'
set_par = function(x, value, ...) {
  x = as.relistable(x)
  val = unlist(x)
  val[] = value
  val = relist(val)
  class(val) = "osmose.configuration"
  return(val)
}

#' @exportS3Method relist osmose.configuration
relist.osmose.configuration = function(flesh, skeleton = attr(flesh, "skeleton")) {
  ind <- 1L
  result <- skeleton
  for (i in seq_along(skeleton)) {
    size <- length(unlist(result[[i]]))
    result[[i]] <- relist(flesh[seq.int(ind, length.out = size)], 
                          result[[i]])
    ind <- ind + size
  }
  result
}

mcat = function(..., file = "", sep = " ", fill = FALSE, labels = NULL,
                append = FALSE) {
  for(ifile in file) {
    cat(... , file = ifile, sep = sep, fill = fill, labels = labels,
        append = append)
  }
  return(invisible(NULL))
}

logit = function(x) log(x/(1-x))
ilogit = function(x) 1/(1 + exp(-x))

#' Give Row or Colums Sums of a Matrix or Array, Based on a Grouping Variable 
#' @param group a vector or factor giving the grouping, with one element per column of x. Missing values will be treated as another group and a warning will be given.
#' @inheritParams base::rowsum
#' @export
colsum = function (x, group, reorder = TRUE, ...) {
  UseMethod("colsum")
} 


#' @rdname colsum
#' @export
colsum.default = function(x, group, reorder=TRUE, na.rm=FALSE, ...) {
  x = t(rowsum(t(x), group=group, reorder=reorder, na.rm=na.rm, ...))
  return(x)
}

#' @rdname colsum
#' @export
colsum.matrix = colsum.default

#' @rdname colsum
#' @export
colsum.array = function(x, group, reorder=TRUE, na.rm=FALSE, ...) {
  perm = seq_along(dim(x))
  perm[1:2] = 2:1
  x = rowsum(aperm(x, perm=perm), group=group, reorder=reorder, na.rm=na.rm, ...)
  x = aperm(x, perm=perm)
  return(x)
}


#' @export
rowsum.matrix = rowsum.default

#' @export
rowsum.array = function(x, group, reorder=TRUE, na.rm=FALSE, ...) {
  if(!is.numeric(x)) 
    stop("'x' must be numeric")
  if(length(group) != NROW(x)) 
    stop("incorrect length for 'group'")
  if(anyNA(group)) 
    warning("missing values for 'group'")
  ugroup = unique(group)
  xo = apply(x, seq_along(dim(x))[-c(1:2)], FUN=rowsum.default, group=group, reorder=reorder, na.rm=na.rm, ...)
  dim(xo) = c(length(ugroup), dim(x)[-1])
  dimnames(xo) = c(list(ugroup), dimnames(x)[-1])
  return(xo)
}

