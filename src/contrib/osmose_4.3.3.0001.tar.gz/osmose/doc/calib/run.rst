
Run the calibration
+++++++++++++++++++++

When everything is ready, run the calibration as follows:

.. code-block:: bash
    
    R CMD BATCH calibrate.R

